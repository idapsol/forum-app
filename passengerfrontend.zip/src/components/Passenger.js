import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import { Container, Paper, Button } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      margin: theme.spacing(1),
    },
  },
}));

export default function Passenger() {
  const paperStyle = { padding: "50px 20px", width: 600, margin: "20px auto" };
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [id, setId] = useState("");
  const [age, setAge] = useState("");
  const [luggage, setLuggage] = useState("");
  const [nation, setNation] = useState("");
  const [passengers, setPassengers] = useState([]);
  const classes = useStyles();

  const handleClick = (e) => {
    e.preventDefault();
    const passenger = { firstName, lastName, id, age, luggage, nation };
    console.log(passenger);
    fetch("http://localhost:8080/passenger/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(passenger),
    }).then(() => {
      console.log("New Passenger added");
    });
  };

  useEffect(() => {
    fetch("http://localhost:8080/passenger/getAll")
      .then((res) => res.json())
      .then((result) => {
        setPassengers(result);
      });
  }, []);
  return (
    <Container>
      <Paper elevation={3} style={paperStyle}>
        <h1 style={{ color: "blue" }}>
          <u>Add Passenger</u>
        </h1>

        <form className={classes.root} noValidate autoComplete="off">
          <TextField
            id="outlined-basic"
            label="Passenger First Name"
            variant="outlined"
            fullWidth
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
          />
          <TextField
            id="outlined-basic"
            label="Passenger Last Name"
            variant="outlined"
            fullWidth
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />
          <TextField
            id="outlined-basic"
            label="Passenger ID"
            variant="outlined"
            fullWidth
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />
          <TextField
            id="outlined-basic"
            label="Passenger Age"
            variant="outlined"
            fullWidth
            value={id}
            onChange={(e) => setId(e.target.value)}
          />
          <TextField
            id="outlined-basic"
            label="Does the Passenger have luggage (1 - Yes / 0 - No)"
            variant="outlined"
            fullWidth
            value={luggage}
            onChange={(e) => setLuggage(e.target.value)}
          />
          <TextField
            id="outlined-basic"
            label="Passenger Nationality"
            variant="outlined"
            fullWidth
            value={nation}
            onChange={(e) => setNation(e.target.value)}
          />
          <Button variant="contained" color="secondary" onClick={handleClick}>
            Submit
          </Button>
        </form>
      </Paper>
      <h1>Passengers</h1>

      <Paper elevation={3} style={paperStyle}>
        {passengers.map((passenger) => (
          <Paper
            elevation={6}
            style={{ margin: "10px", padding: "15px", textAlign: "left" }}
            key={passenger.id}
          >
            Id:{passenger.id}
            <br />
            First Name:{passenger.firstName}
            <br />
            Last Name:{passenger.lastName}
            <br />
            Age:{passenger.age}
            <br />
            Luggage:{passenger.luggage}
            <br />
            Nationality:{passenger.nation}
            <br />
          </Paper>
        ))}
      </Paper>
    </Container>
  );
}
