
import './App.css';
import Appbar from './components/Appbar'
import Passenger from './components/Passenger';

function App() {
  return (
    <div className="App">
    <Appbar/>
    <Passenger/>
   
    </div>
  );
}

export default App;

